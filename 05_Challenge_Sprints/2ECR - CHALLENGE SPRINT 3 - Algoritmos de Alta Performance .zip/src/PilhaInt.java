
public class PilhaInt {

	final int N = 8;
	int dados[] = new int[N];
	int topo;

	public void init() {
		topo = 0;
	}

	public boolean isEmpty() {
		if (topo == 0)
			return true;
		else
			return false;
	}

	public boolean isFull() {
		if (topo == N)
			return true;
		else
			return false;
	}

	public void push(int elem) {
		if (isFull())
			System.out.println("Stack Overflow");
		else {
			dados[topo] = elem;
			topo++;
		}
	}
	public int tamanho () {
		return topo;
	}
	public int pop() {
		topo--;
		return (dados[topo]);
	}
	
	public void esvazia() {
		while (!isEmpty())
			System.out.print(" "+ pop());
	}
}