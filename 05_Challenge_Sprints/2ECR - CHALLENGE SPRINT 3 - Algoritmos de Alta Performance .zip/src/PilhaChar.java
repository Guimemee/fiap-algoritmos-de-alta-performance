
public class PilhaChar {

	final int N = 20;
	char dados[] = new char[N];
	int topo;

	public void init() {
		topo = 0;
	}

	public boolean isEmpty() {
		if (topo == 0)
			return true;
		else
			return false;
	}

	public boolean isFull() {
		if (topo == N)
			return true;
		else
			return false;
	}

	public void push(char elem) {
		if (isFull())
			System.out.println("Stack Overflow");
		else {
			dados[topo] = elem;
			topo++;
		}
	}
	
	public int tamanho() {
		return topo;
	}
	
	public char pop() {
		topo--;
		return (dados[topo]);
	}
	
	public void esvazia() {
		while (!isEmpty())
			System.out.print(" "+ pop());
	}
}