import java.lang.String;
public class PilhaString {

	final int N = 30;
	String dados[] = new String[N];
	int topo;

	public void init() {
		topo = 0;
	}

	public boolean isEmpty() {
		if (topo == 0)
			return true;
		else
			return false;
	}

	public boolean isFull() {
		if (topo == N)
			return true;
		else
			return false;
	}

	public void push(String elem) {
		if (isFull())
			System.out.println("Stack Overflow");
		else {
			dados[topo] = elem;
			topo++;
		}
	}

	public String pop() {
		topo--;
		return (dados[topo]);
	}
	
	public void esvazia() {
		while (!isEmpty())
			System.out.print(" "+ pop());
	}
}