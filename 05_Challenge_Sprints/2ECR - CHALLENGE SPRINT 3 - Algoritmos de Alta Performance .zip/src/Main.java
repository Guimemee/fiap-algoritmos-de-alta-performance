import java.util.Scanner;


public class Main {

public static String inverte(String s) {
	int n = s.length();

	for (int j = 0; j < n; ++j) {
		PilhaChar p = new PilhaChar();
		while (j < n && s.charAt(j) != '#' && s.charAt(j) != '_') {
			p.push(s.charAt(j));
			j++;
		}
		int t = p.tamanho();
		char[] buffer = new char[t];
		for (int k = 0; k < t; ++k) {
			buffer[k] = p.pop();
		}
		
		if (j < n)
			s = s.substring(0, j-t) + String.copyValueOf(buffer) + s.charAt(j) + s.substring(j+1);
		else
			s = s.substring(0, j-t) + String.copyValueOf(buffer);
		
	}
	return s;
}

public static String codifica(String s) {
	s = inverte(s);
	int n = s.length();
	int delta = n/4;
	char[] tmp = s.toCharArray();
	for (int j = 0; j < n; ++j) {
		int v = (int) tmp[j] + delta;
		tmp[j] = (char) v;
	}
	s = String.copyValueOf(tmp);
	return s;
}

public static String decodifica(String s) {
	int n = s.length();
	int delta = n/4;
	char[] tmp = s.toCharArray();
	for (int j = 0; j < n; ++j) {
		int v = (int) tmp[j] - delta;
		tmp[j] = (char) v;
	}
	s = String.copyValueOf(tmp);
	s = inverte(s);
	return s;
}

public static String[] inverte(String[] s) {
	PilhaString ps = new PilhaString();
	int n = s.length;
	for (int i = 0; i < n; ++i) {
		ps.push(s[i]);
	}
	for (int i = 0; i < n; ++i) {
		s[i] = ps.pop();
	}
	return s;
}

public static void printMenu(String[] s) {
	System.out.println("****** Logins cadastrados *******\n");
	for (int i = 0; i < s.length; ++i) {
		System.out.println(i + ") " + s[i] + "\n");
	}
}

public static void main(String[] args) {
		
		Scanner le = new Scanner(System.in);
		
		System.out.print("Informe o número de logins: ");
		int qtd_logins = Integer.parseInt(le.nextLine());
		String[] login = new String[qtd_logins];
		String[] senha = new String[qtd_logins];
		String[] senhasCodificadas = new String[qtd_logins];
		PilhaString ps = new PilhaString();
		for (int i = 0; i < qtd_logins; ++i) {
			System.out.print("Login: ");
			login[i] = le.nextLine();
			System.out.print("Senha: ");
			senha[i] = le.nextLine();
			senha[i] = codifica(senha[i]);
			ps.push(senha[i]);
		}
		for (int i = 0; i < qtd_logins; ++i) {
			senhasCodificadas[i] = ps.pop();
		}
		
		while (true) {
			printMenu(login);
			System.out.print("Escolha a posição de um usuário para obter senha decodificada: ");
			int opcao = Integer.parseInt(le.nextLine());
			if (opcao < 0)
				break;
			String[] invertido = inverte(senhasCodificadas);
			System.out.println("Senha original: " + decodifica(invertido[opcao]));
		}
		
		le.close();
	}


}
