//Caio Silva alves rm85350
//Murilo José Cressoni  rm95267
//Kaique Carvalho da Silva rm93040
//Guilherme Macário da Silva - RM 84057
//Bruno Tanaui Zanocco - RM:85770
import java.util.Scanner;
class Designer {
    int cpf;
    String link;
    double notas[]= new double[3];
    double media;
}
public class sprint1 {
	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);	
		
		int numDesign = 8;
		
		Designer designers[]= new Designer[numDesign];
		
		for (int i = 0; i < numDesign; i++) {
			designers[i] = new Designer();
			
			System.out.print("CPF " + (i + 1) + ":\n");		         
			designers[i].cpf = ler.nextInt();
			
			System.out.print("link do Google Drive" + (i + 1) + ":");
			
			designers[i].link = ler.next();
			
			System.out.print("notas atribuidas designer: " + (i + 1) + ":");
		
			designers[i].notas[0] = ler.nextDouble();
			System.out.print("nota atribuida");
			designers[i].notas[1] = ler.nextDouble();
			System.out.print("nota atribuida");
			designers[i].notas[2] = ler.nextDouble();
			
			designers[i].media = (designers[i].notas[0] + designers[i].notas[1] + designers[i].notas[2]) / 3;
			
			String duascasasdecimais= String.format("%.1f" , designers[i].media);
			
			System.out.print("Média do designer:" + duascasasdecimais + "\n");
		 }

		System.out.print("maiores medias");
		for (int i = 0; i < numDesign; i++) {
			if (designers[i].media >= 7) {
			System.out.print("CPF: " + designers[i].cpf +"\n");
			System.out.print("Média: " + designers[i].media + "\n");
			}
		}
		
		double maiorNota = 0;
		int vencedor = 0;
		boolean empate = false;
		
		for(int i = 0; i < numDesign; i++) {
			if(designers[i].media > maiorNota) {
				empate = false;
				maiorNota = designers[i].media;
				vencedor = i; 
				
			}
			else if (designers[i].media == maiorNota) {	
				empate = true;
				
				//voto de minerva 
				 System.out.println("voto de minerva. Escolha o cpf do vencedor:");
	            int opcao = ler.nextInt();
	            if (opcao == designers[i].cpf) {
	                System.out.println("O grande vencedor é o CPF: " + designers[i].cpf);
	                System.out.println("Link do Google Drive: " + designers[i].link);
	            	}
	            }
	            
			} 

		if (!empate) {
	        System.out.println("O vencedor é o CPF: " + designers[vencedor].cpf);
	        System.out.println("Link do Google Drive: " + designers[vencedor].link);
		}
		
		
ler.close();
		
	}

}
