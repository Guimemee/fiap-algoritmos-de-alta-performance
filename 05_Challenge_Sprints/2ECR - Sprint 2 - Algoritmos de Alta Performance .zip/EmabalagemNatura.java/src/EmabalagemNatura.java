//Caio Silva alves rm85350
//Murilo José Cressoni  rm95267
//Kaique Carvalho da Silva rm93040
//Guilherme Macário da Silva - RM 84057

import java.util.Scanner;
class Designer {
    int cpf;
    String link;
    double notas[]= new double[3];
    double media;
}		

public class EmabalagemNatura {
	
	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);	
		
	int numDesign = 8;
	
	Designer designers[]= new Designer[numDesign];
	
	for (int i = 0; i < numDesign; i++) {
		designers[i] = new Designer();
		
		System.out.print("CPF " + (i + 1) + ":\n");		         
		designers[i].cpf = ler.nextInt();
		
		System.out.print("link do Google Drive" + (i + 1) + ":");
		
		designers[i].link = ler.next();
		
		System.out.print("notas atribuidas designer: " + (i + 1) + ":");
	
		designers[i].notas[0] = ler.nextDouble();
		System.out.print("nota atribuida");
		designers[i].notas[1] = ler.nextDouble();
		System.out.print("nota atribuida");
		designers[i].notas[2] = ler.nextDouble();
		
		designers[i].media = (designers[i].notas[0] + designers[i].notas[1] + designers[i].notas[2]) / 3;
		
		String duascasasdecimais= String.format("%.1f" , designers[i].media);
		
		System.out.print("Média do designer:" + duascasasdecimais + "\n");
	 }
	 System.out.println("\n Ordenacao por CPF:");
	 
     // Ordenar pelo CPF usando QuickSort
	 
     quickSortCPF(designers, 0, numDesign - 1);
     
     
     for (int i = 0; i < numDesign; i++) {
         System.out.println("CPF: " + designers[i].cpf);
         System.out.println("Média: " + designers[i].media);
         System.out.println("Link do Google Drive: " + designers[i].link);
         System.out.println();
     }

	System.out.print("maiores medias");
	for (int i = 0; i < numDesign; i++) {
		if (designers[i].media >= 7) {
		System.out.print("CPF: " + designers[i].cpf +"\n");
		System.out.print("Média: " + designers[i].media + "\n");
		}
	}
	
	double maiorNota = 0;
	int vencedor = 0;
	boolean empate = false;
	
	for(int i = 0; i < numDesign; i++) {
		if(designers[i].media > maiorNota) {
			empate = false;
			maiorNota = designers[i].media;
			vencedor = i; 
			
		}
		else if (designers[i].media == maiorNota) {	
			empate = true;
			
			//voto de minerva 
			 System.out.println("voto de minerva. Escolha o cpf do vencedor:");
            int opcao = ler.nextInt();
            if (opcao == designers[i].cpf) {
                System.out.println("O grande vencedor é o CPF: " + designers[i].cpf);
                System.out.println("Link do Google Drive: " + designers[i].link);
            	}
            }
            
		} 

	if (!empate) {
        System.out.println("O vencedor é o CPF: " + designers[vencedor].cpf);
        System.out.println("Link do Google Drive: " + designers[vencedor].link);
	}
  
	// Consulta de projetos pelo CPF
    System.out.println("\nConsulta de Projetos");
    char opcao;
    do {
        System.out.print("Digite o CPF para consultar o projeto: ");
        int cpfConsulta = ler.nextInt();
        int indice = buscaBinariaCPF(designers, cpfConsulta);

        if (indice == -1) {
            System.out.println("CPF não encontrado.");
        } else {
            Designer designerConsulta = designers[indice];
            System.out.println("Link do Google Drive: " + designerConsulta.link);
            System.out.println("Média: " + designerConsulta.media);
        }

        System.out.print("Deseja fazer outra consulta? (S/N): ");
        opcao = ler.next().charAt(0);
    }
    while (opcao == 'S' || opcao == 's');

    ler.close();
}

	
	// Implementação do QuickSort 
    public static void quickSortCPF(Designer[] designers, int baixo, int alto) {
        if (baixo < alto) {
            int pi = partição(designers, baixo, alto);

            quickSortCPF(designers, baixo, pi - 1);
            quickSortCPF(designers, pi + 1, alto);
        }
    }

    private static int partição(Designer[] designers, int baixo, int alto) {
        int pivot = designers[alto].cpf;
        int i = baixo - 1;

        for (int j = baixo; j < alto; j++) {
            if (designers[j].cpf < pivot) {
                i++;

                Designer temp = designers[i];
                designers[i] = designers[j];
                designers[j] = temp;
            }
        }

        Designer temp = designers[i + 1];
        designers[i + 1] = designers[alto];
        designers[alto] = temp;

        return i + 1;
    }

    // Implementação da busca binária pelo CPF
    public static int buscaBinariaCPF(Designer[] designers, int cpfConsulta) {
        int esquerda = 0;
        int direita = designers.length - 1;

        while (esquerda <= direita) {
            int meio = (esquerda + direita) / 2;

            if (designers[meio].cpf == cpfConsulta) {
                return meio; // Retorna o índice onde o CPF foi encontrado
            }

            if (designers[meio].cpf < cpfConsulta) {
                esquerda = meio + 1;
            } else {
                direita = meio - 1;
            }
        }

        return -1; // Retorna -1 se o CPF não for encontrado
    }
}

  



