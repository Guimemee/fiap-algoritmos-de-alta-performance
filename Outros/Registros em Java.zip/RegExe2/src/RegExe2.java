import java.util.Scanner;

public class RegExe2
{
	public static void main(String[] args)
	{
		class registroAgenda
		{
			private String nome;
			private String email;
			private String telefone;

			public registroAgenda(String Nome, String Email, String Telefone)
			{
				nome = Nome;
				email = Email;
				telefone = Telefone;
			}

			public String getNome()
			{
				return nome;
			}

			public void setNome(String Nome)
			{
				nome = Nome;
			}

			public String getEmail()
			{
				return email;
			}

			public void setEmail(String Email)
			{
				email = Email;
			}

			public String getTelefone()
			{
				return telefone;
			}

			public void setTelefone(String Telefone)
			{
				telefone = Telefone;
			}
		}

	  	Scanner entrada = new Scanner(System.in);
	  	String NOME, EMAIL, FONE;

    	System.out.print("\nDigite o nome: ");
    	NOME = entrada.nextLine();
    	System.out.print("Digite o e-mail: ");
    	EMAIL = entrada.nextLine();
    	System.out.print("Digite o telefone: ");
    	FONE = entrada.nextLine();

    	registroAgenda regAG = new registroAgenda(NOME, EMAIL, FONE);

    	System.out.print("\nnome:\t\t" + regAG.getNome() + "\n");
    	System.out.print("e-mail:\t\t" + regAG.getEmail() + "\n");
    	System.out.print("telefone:\t"+ regAG.getTelefone() + "\n");

    	System.out.println("\n>>> ATUALIZAÇÃO CADASTRAL <<<");
    	System.out.print("\nConfirme o nome: ");
    	regAG.setNome(entrada.nextLine());
    	System.out.print("Confirme o e-mail: ");
    	regAG.setEmail(entrada.nextLine());
    	System.out.print("Confirme o telefone: ");
    	regAG.setTelefone(entrada.nextLine());

    	System.out.print("\nnome:\t\t" + regAG.getNome() + "\n");
    	System.out.print("e-mail:\t\t" + regAG.getEmail() + "\n");
    	System.out.print("telefone:\t"+ regAG.getTelefone() + "\n");

    	entrada.close();
	}
}
