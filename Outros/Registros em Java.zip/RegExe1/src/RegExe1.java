import java.util.Scanner;
import java.text.DecimalFormat;

public class RegExe1
{
	public static final int COLABORADORES = 3;

	public static class Colaborador
	{
		public String nome;
		public String endereco;
		public String telefone;
		public float salario;
		public int idade;
	}
	
	public static void main(String[] args)
	{
		Scanner entrada = new Scanner(System.in);
		int i = 0;
		Colaborador colaboradores[] = new Colaborador[COLABORADORES];

		// instancia o objeto da classe DecimalFormat
		// para formatar valores em R$ (Reais)
		DecimalFormat R$;
		R$ = new DecimalFormat ("R$ 0,000.00");

		// obtém os dados dos colaboradores
		for (i = 0; i < colaboradores.length; i++)
		{
			// Colaborador colaboradores[] = new Colaborador[3];
			// declara o vetor e seu tipo, como o tipo é um objeto,
			// por padrão (default) as posições vão receber o valor NULL
			// desta forma, é necessário "preencher" cada posição do vetor
			colaboradores[i] = new Colaborador();
			System.out.print("\nDigite o nome do colaborador: ");
			colaboradores[i].nome = entrada.nextLine();
			System.out.print("Digite o endereço do colaborador: ");
			colaboradores[i].endereco = entrada.nextLine();
			System.out.print("Digite o telefone do colaborador: ");
			colaboradores[i].telefone = entrada.nextLine();
			System.out.print("Digite o salário do colaborador: ");
			colaboradores[i].salario = entrada.nextFloat();
			System.out.print("Digite a idade do colaborador: ");
			colaboradores[i].idade = entrada.nextInt();
			entrada.nextLine();
		}

		// exibe os dados dos colaboradores
		for (i = 0; i < colaboradores.length; i++)
		{
			System.out.print("\n" + colaboradores[i].nome + ", " + colaboradores[i].idade + " anos");
			System.out.print("\n" + colaboradores[i].endereco + ", telefone: (11) " + colaboradores[i].telefone);
			System.out.print("\n" + R$.format(colaboradores[i].salario));
			System.out.print("\n");
		}

		entrada.close();
	}
}
