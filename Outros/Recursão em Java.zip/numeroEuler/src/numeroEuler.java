import java.util.Scanner;

public class numeroEuler
{
	public static void main(String[] args)
	{
		Scanner teclado = new Scanner(System.in);
		int k;
		double e;

		System.out.print("Informe k: ");
		k = teclado.nextInt();

	    if (k <= 0)
	    	System.out.println("k deve ser > 0");
	    else
	    {
	        e = numeroE(k);
	        System.out.println("\ne= " + e);
	    }

	    teclado.close();
	}

	public static double numeroE(int k)
	{
	    double um = 1;

	    if (k == 0)
	        return (1);
	    else
	    return ((um/fatorial(k)) + numeroE(k-1));
	}

	public static long fatorial(int N)
	{
		if (N == 0)
			return 1;
		else
			return (N*fatorial(N-1));
	}
}
