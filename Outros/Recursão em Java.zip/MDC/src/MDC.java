import java.util.Scanner;

public class MDC
{
	public static void main(String[] args)
	{
		Scanner teclado = new Scanner(System.in);
		int m, n;

		System.out.print("Informe m (m>0): ");
		m = teclado.nextInt();
		System.out.print("Informe n (n>0): ");
		n = teclado.nextInt();

		System.out.println("\nMDC(" + m + "," + n + ")= " + mdc(m,n));

		teclado.close();
	}

	public static int mdc(int m, int n)
	{
		if (m < n)
			mdc(n,m);
		 if(n != 0)
		       return mdc(n, m%n);
		    else 
		       return m;
		//if ((m % n == 0))
			//return n;
		//else
			//return mdc(n, m%n);
	}
	
}
