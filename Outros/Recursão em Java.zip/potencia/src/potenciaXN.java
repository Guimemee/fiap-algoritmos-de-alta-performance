import java.util.Scanner;

public class potenciaXN
{
	public static void main(String[] args)
	{
		Scanner teclado = new Scanner(System.in);
		int x, y, potencia;

		System.out.print("Informe x: ");
		x = teclado.nextInt();
		System.out.print("Informe y: ");
		y = teclado.nextInt();

		potencia = potencia(x, y);
		System.out.println("\n" + x + "^" + y + "= " + potencia);

		teclado.close();
	}

	public static int potencia(int x, int n)
	{
		if (x == 1 || n == 0)
			return (1);

		if (x == 0 || n == 1)
			return (x);

		return (x*potencia(x, n-1));
	}
}
