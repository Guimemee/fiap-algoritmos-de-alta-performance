import java.util.Scanner;

public class decimal_2_binario
{
	public static void main(String[] args)
	{
		Scanner teclado = new Scanner(System.in);
		int N;

		System.out.print("Informe N (N>0): ");
		N = teclado.nextInt();

		System.out.print("\n" + N + " em bin�rio �: ");
		binario(N);
		teclado.close();
	}

	public static void binario(int N)
	{
		if (N == 0)
			return;

		binario(N/2);
		System.out.print(N%2);
	}
}
