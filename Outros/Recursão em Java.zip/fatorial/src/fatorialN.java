import java.util.Scanner;
import java.text.DecimalFormat;

public class fatorialN
{
	public static void main(String[] args)
	{
		Scanner teclado = new Scanner(System.in);
		DecimalFormat f = new DecimalFormat("###,###");
		int N;
		long fat;

		System.out.print("Informe N: ");
		N = teclado.nextInt();
		
		fat = fatorial(N);
		System.out.println("\n" + N + "!= " + f.format(fat));

		teclado.close();
	}

	public static long fatorial(int N)
	{
		if (N == 0)
			return 1;
		else
			return (N*fatorial(N-1));
	}
}



