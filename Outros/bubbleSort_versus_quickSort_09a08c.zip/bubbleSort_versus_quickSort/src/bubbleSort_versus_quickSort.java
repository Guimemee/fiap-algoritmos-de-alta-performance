
public class bubbleSort_versus_quickSort
{
	public static void main(String[] args)
	{


	}

	public static void bubbleSort(int vetor[])
	{
		for(int i = 0; i < vetor.length-1; i++) {
			boolean troca = false;
			for(int j = 0; j < (vetor.length-1)-i; j++) {
				if(vetor[j] > vetor[j+1]) {
					troca = true;
					int aux = vetor[j];
					vetor[j] = vetor[j+1];
					vetor[j+1] = aux;
				}
			}

			if(troca == false)
				break;
		}
	}

	public static void quickSort(int vetor[], int inicio, int fim)
	{
		int i = inicio;
		int j = fim - 1;
		int pivo = vetor[(inicio + fim)/2];
		while (i <= j) {

			while (vetor[i] < pivo && i < fim) 	{
				i++;
			}

			while (vetor[j] > pivo && j > inicio) {
				j--;
			}

			if (i <= j) {
				int aux = vetor[i];
				vetor[i] = vetor[j];
				vetor[j] = aux;
				i++;
				j--;
			}
		}

		if(j > inicio)
			quickSort(vetor, inicio, j+1);

		if(i < fim)
			quickSort(vetor, i, fim);
	}
}
