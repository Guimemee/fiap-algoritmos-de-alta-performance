package aplicacao;

import java.util.Scanner;

import arvores.ABBint;

public class Exemplo {

	public static void main(String[] args) {

		ABBint abb = new ABBint();
		Scanner le = new Scanner(System.in);
		int opcao;
		do {
			System.out.println(" 0 - Sair");
			System.out.println(" 1 - Inserir");
			System.out.println(" 2 - Apresenta ABB em ordem crescente");
			System.out.print(" Opcao: ");
			opcao = le.nextInt();
			switch (opcao) {
			case 0:
				System.out.println("Programa finalizado");
				break;
			case 1:
				System.out.print(" Informe valor a ser inserido na ABB: ");
				int info = le.nextInt();
				abb.raiz = abb.inserir(abb.raiz, info);
				break;
			case 2:
				if (abb.raiz==null)
					System.out.println("Arvore esta vazia");
				else {
					System.out.println("\t********Apresentacao da ABB*******");
					abb.listaEmOrdem(abb.raiz);
					System.out.println("\n\t**********************************");
				}
				break;
			default:
				System.out.println("Op��o inv�lida");
			}
		} while (opcao != 0);
		le.close();

	}

}
