import java.util.Scanner;

public class arvoreBinaria
{
	public static final int SAIR = 0;

	public static Scanner teclado = new Scanner(System.in);

	public static class ARVORE
	{
		public int numero;
		public ARVORE dir, esq;
	}

	public static ARVORE raiz = null;
	public static ARVORE aux;

	public static void main(String[] args)
	{
		int opcao;

		do
		{
			// exibe o menu de opera��es que podem ser executadas,
			// obt�m a op��o selecionada e executa esta op��o
			opcao = menu();
			operacao(opcao);
		} while(opcao != SAIR);
	}

	public static int menu()
	{
		int opcao;

		// exibe o menu de opera��es
		System.out.println("Selecione a op��o desejada:\n");
		System.out.println("0. Sair");
		System.out.println("1. Inserir n� na �RVORE");
		System.out.println("2. Remover n� da �RVORE");
		System.out.println("3. Consultar n� na �RVORE");
		System.out.println("4. Percorrer �RVORE em ordem");
		System.out.println("5. Percorrer �RVORE em pr�-ordem");
		System.out.println("6. Percorrer �RVORE em p�s-ordem");
		System.out.println("7. Esvaziar a �RVORE");
		System.out.print("op��o: ");
		// e obt�m a op��o desejada pelo usu�rio
		opcao = teclado.nextInt();
		return (opcao);
	}

	public static void operacao(int opcao)
	{
		int elemento;
		boolean achou;

		switch (opcao)
		{
			case 0:				// Sair
				System.out.println("FIM da execu��o.");
				teclado.close();
				break;
			case 1:				// Inserir n� na �RVORE
				// obt�m o elemento a inserir na �RVORE
				System.out.print("elemento a inserir na �RVORE: ");
				elemento = teclado.nextInt();
				raiz = inserirArvore(raiz, elemento);
				break;
			case 2:				// Remover n� da �RVORE
				// obt�m o elemento a remover da �RVORE
				System.out.print("elemento a remover da �RVORE: ");
				elemento = teclado.nextInt();
				achou = consultarArvore(raiz, elemento, false);
				if (achou == true)
					raiz = removerArvore(raiz, elemento);
				else
					System.out.println("elemento n�o encontrado na �RVORE");
				break;
			case 3:				// Consultar n� na �RVORE
				if (arvoreVazia() == false)
				{
					// obt�m o elemento a consultar na �RVORE
					System.out.print("elemento a consultar na �RVORE: ");
					elemento = teclado.nextInt();
					achou = consultarArvore(raiz, elemento, false);
					if (achou == true)
						System.out.println("elemento encontrado na �RVORE");
					else
						System.out.println("elemento n�o encontrado na �RVORE");
				}
				break;
			case 4:				// Consultar �RVORE em ordem
				percorrerArvoreOrdem(raiz);
				break;
			case 5:				// Consultar �RVORE em pr�-ordem
				percorrerArvorePreOrdem(raiz);
				break;
			case 6:				// Consultar �RVORE em p�s-ordem
				percorrerArvorePosOrdem(raiz);
				break;
			case 7:				// Esvaziar a �RVORE
				if (arvoreVazia() == false)
					raiz = null;
				break;
			default:
				System.out.println("op��o INV�LIDA!\n");
		}

		System.out.println();
	}

	public static boolean arvoreVazia()
	{
		if (raiz == null)
		{
			System.out.println("�RVORE vazia!");
			return (true);
		}
		else
			return (false);
	}

	public static ARVORE inserirArvore(ARVORE aux, int elemento)
	{
		if (aux == null)
		{
			aux = new ARVORE();
			aux.numero = elemento;
			aux.esq = null;
			aux.dir = null;
		}
		else
			if (elemento < aux.numero)
				aux.esq = inserirArvore(aux.esq, elemento);
			else
				aux.dir = inserirArvore(aux.dir, elemento);
		return aux;
	}

	public static ARVORE removerArvore(ARVORE aux, int elemento)
	{
		ARVORE ptr1, ptr2;

		if (aux.numero == elemento)
		{
			if (aux.esq == aux.dir)
				return null;			// n� a remover n�o tem filhos
			else
				if (aux.esq == null)
					return aux.dir;		// n� a remover n�o tem filhos � esquerda
				else
					if (aux.dir == null)
						return aux.esq;	// n� a remover n�o tem filhos � direita
					else
						// n� a remover tem filhos em ambos os lados
						{
							// encontra o n� mais � direita da sub�rvore
							// esquerda do n� que se deseja remover
							ptr1 = aux.esq;
							ptr2 = null;
							while (ptr1.dir != null)
							{
								ptr2 = ptr1;
								ptr1 = ptr1.dir;
							}
							// "permuta" elementos 
							aux.numero = ptr1.numero;
							// remove n�
							if (ptr2 != null)
								ptr2.dir = null;
							else
								aux.esq = null;
							return aux;
						}
		}
		else
			if (aux.numero < elemento)
				aux.dir = removerArvore(aux.dir, elemento);
			else
				aux.esq = removerArvore(aux.esq, elemento);

		return aux;
	}

	public static boolean consultarArvore(ARVORE aux, int elemento, boolean achou)
	{
		if (aux != null && achou == false)
			if (aux.numero == elemento)
				achou = true;
			else
				if (elemento < aux.numero)
					achou = consultarArvore(aux.esq, elemento, achou);
				else
					achou = consultarArvore(aux.dir, elemento, achou);

		return achou;
	}

	public static void percorrerArvoreOrdem(ARVORE aux)
	{
		if (aux != null)
		{
			percorrerArvoreOrdem(aux.esq);
			System.out.print(aux.numero + ", ");
			percorrerArvoreOrdem(aux.dir);
		}
	}

	public static void percorrerArvorePreOrdem(ARVORE aux)
	{
		if (aux != null)
		{
			System.out.print(aux.numero + ", ");
			percorrerArvorePreOrdem(aux.esq);
			percorrerArvorePreOrdem(aux.dir);
		}
	}

	public static void percorrerArvorePosOrdem(ARVORE aux)
	{
		if (aux != null)
		{
			percorrerArvorePosOrdem(aux.esq);
			percorrerArvorePosOrdem(aux.dir);
			System.out.print(aux.numero + ", ");
		}
	}
}
