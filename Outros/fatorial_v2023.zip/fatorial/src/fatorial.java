import java.util.Scanner;
import java.text.DecimalFormat;

public class fatorial
{
	public static void main(String[] args)
	{
		Scanner teclado = new Scanner(System.in);
		DecimalFormat formatador = new DecimalFormat("###,###,###");
		int N, i;
		long fat;

		do
		{
			System.out.print("Informe N (N<=12): ");
			N = teclado.nextInt();
		}while(N < 0);

		System.out.println("N! : for(){}");
		fat = 1;
		for(i = N; i > 1; i--)
			fat = fat * i;
		System.out.println("N!= " + formatador.format(fat));

		System.out.println("\nN! : while(){}");
		fat = 1;
		i = 1;
		while(i <= N)
		{
			fat = fat * i;
			i++;
		}
		System.out.println("N!= " + formatador.format(fat));

		System.out.println("\nN! : do{} while()");
		fat = 1;
		i = 1;
		do
		{
			fat = fat * i;
			i++;
		}while(i <= N);
		System.out.println("N!= " + formatador.format(fat));

		teclado.close();
	}
}
