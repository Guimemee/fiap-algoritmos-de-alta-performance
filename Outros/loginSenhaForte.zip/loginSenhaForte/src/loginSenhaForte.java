import java.util.Scanner;
import java.util.Random;

public class loginSenhaForte
{
	public static final int SENHA = 20;
	public static final int ALFABETO = 26;
	public static final int DIGITOS = 10;
	public static final int ESPECIAIS = 23;
	public static final int SIMBOLOS = 4;

	public static void main(String[] args)
	{
		Scanner teclado = new Scanner(System.in);
		String Nome = "";
		String login = "";
		String senha = "";
		int i, j;

		System.out.print("Informe o seu nome: ");
		Nome = teclado.nextLine().toLowerCase();;

		char nome[] = Nome.toCharArray();
		login = login + Nome.charAt(0);
		for (i = nome.length - 1; i >= 0; i--)
			if (nome[i] == ' ')
			{
				for (j = i+1; j < nome.length; j++)
					login = login + nome[j];

				break;
			}

		senha = gerarSenha();
		
		System.out.println();
		System.out.println("nome:  " + Nome);
		System.out.println("login: " + login);
		System.out.println("senha: " + senha);
		teclado.close();
	}

	public static String gerarSenha()
	{
		String LETRAS =    "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String letras =    "abcdefghijklmnopqrstuvwxyz";
		String digitos =   "0123456789";
		String especiais = "!?@#$%&*{[()]}-+=<>:;,.";
		String senha = new String();
		Random r = new Random();
		int N, i;
		int LT, lt, dg, es;

		LT = SENHA/SIMBOLOS;
		lt = LT;
		dg = LT;
		es = LT;

		for (i = 0; i < SENHA; i++)
		{
			switch (r.nextInt(SIMBOLOS))
			{
				case 0:
					if (LT > 0)
					{
						N = r.nextInt(ALFABETO);
						senha = senha + LETRAS.charAt(N);
						LT--;
					}
					else
						i--;
					break;

				case 1:
					if (lt > 0)
					{
						N = r.nextInt(ALFABETO);
						senha = senha + letras.charAt(N);
						lt--;
					}
					else
						i--;
					break;

				case 2:
					if (dg > 0)
					{
						N = r.nextInt(DIGITOS);
						senha = senha + digitos.charAt(N);
						dg--;
					}
					else
						i--;
					break;

				case 3:
					if (es > 0)
					{
						N = r.nextInt(ESPECIAIS);
						senha = senha + especiais.charAt(N);
						es--;
					}
					else
						i--;
					break;

				default:
					break;
			}
		}

		return(senha);
	}
}
