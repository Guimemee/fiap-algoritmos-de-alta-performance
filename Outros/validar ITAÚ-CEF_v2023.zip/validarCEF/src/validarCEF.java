
public class validarCEF
{
	public static void main(String[] args)
	{
		int  CEF[] = {2, 0, 0, 4, 0, 0, 1, 0, 0, 0, 0, 0, 4, 4, 8, 6};
		int peso[] = {8, 7, 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2};
		int i, soma, DVi, DVc;

		DVi = CEF[CEF.length-1];
		soma = 0;
		for (i = 0; i < CEF.length-1; i++)
			soma = soma + peso[i]*CEF[i] ;

		DVc = (10*soma) % 11;
		if (DVc == 10)
			DVc = 0;

		if (DVc == DVi)
			System.out.println("conta CEF VALIDA!");
		else
			System.out.println("conta CEF INVALIDA!");
	}
}
