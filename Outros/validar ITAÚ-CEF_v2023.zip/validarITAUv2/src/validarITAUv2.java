
public class validarITAUv2
{
	public static void main(String[] args)
	{
		int ITAU[] = {2, 5, 4, 5, 0, 2, 3, 6, 6, 1};
		int peso[] = {2, 1, 2, 1, 2, 1, 2, 1, 2};
		int i, soma, mult, DVi, DVc;

		DVi = ITAU[ITAU.length-1];
		soma = 0;
		for (i = 0; i < ITAU.length-1; i++)
		{
			mult = peso[i]*ITAU[i] ;
			if (mult >= 10)
				mult = mult - 9;
			soma = soma + mult;
		}

		DVc = soma % 10;
		if (DVc > 0)
			DVc = 10 - DVc;

		if (DVc == DVi)
			System.out.println("conta ITAU VALIDA!");
		else
			System.out.println("conta ITAU INVALIDA!");
	}
}
