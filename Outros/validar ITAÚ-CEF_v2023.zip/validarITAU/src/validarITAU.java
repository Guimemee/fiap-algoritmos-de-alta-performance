
public class validarITAU
{
	public static void main(String[] args)
	{
		int ITAU[] = {2, 5, 4, 5, 0, 2, 3, 6, 6, 1};
		int i, soma, peso, mult, DVi, DVc;

		DVi = ITAU[ITAU.length-1];
		soma = 0;
		peso = 2;
		for (i = 0; i < ITAU.length-1; i++)
		{
			mult = peso*ITAU[i] ;
			if (mult >= 10)
				mult = mult - 9;
			soma = soma + mult;
			peso--;
			if (peso == 0)
				peso = 2;
		}

		DVc = soma % 10;
		if (DVc > 0)
			DVc = 10 - DVc;

		if (DVc == DVi)
			System.out.println("conta ITAU VALIDA!");
		else
			System.out.println("conta ITAU INVALIDA!");
	}
}
