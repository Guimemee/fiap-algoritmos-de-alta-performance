import java.util.Scanner;

public class pilha
{
	public static class Elemento
	{
		public int dado;
		public Elemento prxElemento;
	}

	public static Elemento PILHA = new Elemento();

	public static Scanner teclado = new Scanner(System.in);

	public static int elementos = 0;

	public static void main(String[] args)
	{
		PILHA.prxElemento = null;
		int opcao;

		do
		{
			// exibe o menu de opera��es que podem ser executadas,
			// obt�m a op��o selecionada e executa esta op��o
			opcao = menu();
			operacao(opcao);
		} while(opcao != 0);
	}

	public static void empilhar(int dado)
	{
		// cria um novo elemento
		Elemento novo = new Elemento();

		// armazena o dado neste novo elemento
		novo.dado = dado;
		// (�ltimo elemento da PILHA)-> null
		novo.prxElemento = null;

		// auxiliar-> PILHA
		Elemento auxiliar = PILHA;
		// enquanto n�o chegar ao �ltimo elemento da PILHA...
		while(auxiliar.prxElemento != null)
			// ...percorre todos os elementos da PILHA
			auxiliar = auxiliar.prxElemento;

		// empilha elemento na PILHA
		auxiliar.prxElemento = novo;

		// atualiza o n�mero de elementos da PILHA
		elementos++;
	}
	
	public static int desempilhar()
	{
		// PILHA vazia?
		if (vazia() == true)
		{
			// sim, n�o h� nenhum elemento para desempilhar
			System.out.println("PILHA vazia!");
			return (0);
		}
		else
		{
			// n�o, ultimo-> PILHA
			Elemento ultimo = PILHA;
			Elemento penultimo = null;
			// enquanto n�o chegar ao �ltimo elemento da PILHA...
			while(ultimo.prxElemento != null)
			{
				// penultimo-> elemento anterior ao elemento apontado por ultimo
				penultimo = ultimo;
				// ultimo-> pr�ximo elemento da PILHA
				ultimo = ultimo.prxElemento;
			}
			// desempilha o �ltimo elemento empilhado na PILHA
			// (ajusta �ltimo elemento como null)
			penultimo.prxElemento = null;
			// atualiza o n�mero de elementos da PILHA
			elementos--;
			// retorna o �ltimo elemento empilhado na PILHA
			return (ultimo.dado);
		}
	}

	public static boolean vazia()
	{
		// PILHA vazia?
		if (PILHA.prxElemento == null)
			// sim
			return (true);
		else
			// n�o
			return (false);
	}

	public static int menu()
	{
		int opcao;

		// exibe o menu de opera��es
		System.out.println("Selecione a opera��o desejada:\n");
		System.out.println("0. Sair");
		System.out.println("1. Exibir PILHA");
		System.out.println("2. EMPILHAR");
		System.out.println("3. DESEMPILHAR\n");
		System.out.print("op��o: ");
		// e obt�m a op��o desejada pelo usu�rio
		opcao = teclado.nextInt();
		return (opcao);
	}

	public static void operacao(int opcao)
	{
		//int dado;

		switch (opcao)
		{
			case 0:				// Sair
				System.out.println("FIM da execu��o.");
				teclado.close();
				break;
			case 1:				// Exibir PILHA
				exibir();
				break;
			case 2:				// EMPILHAR
				// obt�m o pr�ximo elemento a empilhar na PILHA
				System.out.print("pr�ximo elemento: ");
				int dado = teclado.nextInt();
				empilhar(dado);
				break;
			case 3:				// DESEMPILHAR
				if (vazia() == false)
					System.out.println("elemento removido: "
							+ desempilhar());
				else
					System.out.println("PILHA vazia!");
				break;
			default:
					System.out.println("Comando INV�LIDO!\n");
		}

		System.out.println();
	}

	public static void exibir()
	{
		// PILHA vazia?
		if (vazia() == true)
		{
			// sim
			System.out.println("PILHA vazia!");
		}
		else
		{
			// n�o,
			int valores[] = new int[elementos];
			int i = 0;
			// n�o, auxiliar-> 1� elemento da PILHA
			Elemento auxiliar = PILHA.prxElemento;
			// enquanto n�o chegar no �ltimo elemento inserido na PILHA
			while(auxiliar.prxElemento != null)
			{
				// armazena o valor do elemento inserido nesse elemento
				valores[i++] = auxiliar.dado;
				// auxiliar-> pr�ximo elemento da PILHA
				auxiliar = auxiliar.prxElemento;
			}

			// armazena o valor do elemento do topo da PILHA 
			valores[i] = auxiliar.dado;

			System.out.print("PILHA:");
			// enquanto n�o chegar ao primeiro elemento empilhado na PILHA
			for(i = valores.length-1; i >= 0; i--)
				// exibe o valor do dado inserido nesse elemento
				System.out.println(((i == valores.length-1)?
						"  " : "\t") + valores[i]);
		}
	}
}
