package verificaTriangulo;

import java.util.Scanner;

public class verificaTriangulo
{

	public static void main(String[] args)
	{
		Scanner teclado = new Scanner(System.in);
		int L1, L2, L3;
		boolean C1, C2, C3;
		int hip, ct1, ct2;

		hip = 0;
		System.out.print("Informe L1: ");
		L1 = teclado.nextInt();
		System.out.print("Informe L2: ");
		L2 = teclado.nextInt();
		System.out.print("Informe L3: ");
		L3 = teclado.nextInt();

		C1 = ((Math.abs(L2-L3) < L1) && (L1 < (L2+L3))); 
		C2 = ((Math.abs(L1-L3) < L2) && (L2 < (L1+L3)));
		C3 = ((Math.abs(L2-L1) < L3) && (L3 < (L2+L1)));

		if (C1 && C2 && C3)
		{
			System.out.print("Eh um triangulo... ");
			if((L1==L2) && (L2==L3))
				System.out.println("equilatero.");
			else
				if ((L1!=L2) && (L1!=L3) && (L2!=L3))
				{
					System.out.print("escaleno");
					hip = Math.max(L1, Math.max(L2, L3));
					ct1 = Math.min(L1, Math.min(L2, L3));
					ct2 = (L1+L2+L3) - (hip+ct1);
					if (Math.pow(hip,2) == Math.pow(ct1,2) + Math.pow(ct2,2))
						System.out.println(" e retangulo.");
					else
						System.out.println(", mas nao eh retangulo.");
				}
				else
					 System.out.println("isosceles.");
		}
		else
			System.out.println("NAO Eh um triangulo!");

		teclado.close();
	}
}
