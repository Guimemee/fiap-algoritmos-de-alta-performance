import java.util.Scanner;

public class fila
{
	public static class Elemento
	{
		public int dado;
		public Elemento prxElemento;
	}

	public static Elemento FILA = new Elemento();

	public static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args)
	{
		FILA.prxElemento = null;
		int opcao;

		do
		{
			// exibe o menu de opera��es que podem ser executadas,
			// obt�m a op��o selecionada e executa esta op��o
			opcao = menu();
			operacao(opcao);
		} while(opcao != 0);
	}

	public static void enfileirar(int dado)
	{
		// cria um novo elemento
		Elemento novo = new Elemento();

		// armazena o dado neste novo elemento
		novo.dado = dado;
		// (�ltimo elemento da FILA)-> null
		novo.prxElemento = null;

		// auxiliar-> FILA
		Elemento auxiliar = FILA;
		// enquanto n�o chegar ao �ltimo elemento da FILA...
		while(auxiliar.prxElemento != null)
			// ...percorre todos os elementos da FILA
			auxiliar = auxiliar.prxElemento;

		// insere elemento na FILA
		auxiliar.prxElemento = novo;
	}
	
	public static int desenfileirar()
	{
		// FILA vazia?
		if (vazia() == true)
		{
			// sim, n�o h� nenhum elemento para remover
			System.out.println("FILA vazia!");
			return (0);
		}
		else
		{
			// n�o,
			// primeiro-> 1� elemento da FILA
			Elemento primeiro = FILA.prxElemento;
			// FILA-> pr�ximo elemento da FILA (2� elemento da FILA)
			FILA.prxElemento = primeiro.prxElemento;
			// retorna o 1� elemento inserido na FILA
			return (primeiro.dado);
		}
	}

	public static boolean vazia()
	{
		// FILA vazia?
		if (FILA.prxElemento == null)
			// sim
			return (true);
		else
			// n�o
			return (false);
	}

	public static int menu()
	{
		int opcao;

		// exibe o menu de opera��es
		System.out.println("Selecione a opera��o desejada:\n");
		System.out.println("0. Sair");
		System.out.println("1. Exibir FILA");
		System.out.println("2. ENFILEIRAR");
		System.out.println("3. DESENFILEIRAR\n");
		System.out.print("op��o: ");
		// e obt�m a op��o desejada pelo usu�rio
		opcao = teclado.nextInt();
		return (opcao);
	}

	public static void operacao(int opcao)
	{
		//int dado;

		switch (opcao)
		{
			case 0:				// Sair
				System.out.println("FIM da execu��o.");
				teclado.close();
				break;
			case 1:				// Exibir FILA
				exibir();
				break;
			case 2:				// ENFILEIRAR
				// obt�m o pr�ximo elemento a inserir na FILA
				System.out.print("pr�ximo elemento: ");
				int dado = teclado.nextInt();
				enfileirar(dado);
				break;
			case 3:				// DESENFILEIRAR
				if (vazia() == false)
					System.out.println("elemento removido: "
							+ desenfileirar());
				else
					System.out.println("FILA vazia!");
				break;
			default:
					System.out.println("Comando INV�LIDO!\n");
		}

		System.out.println();
	}

	public static void exibir()
	{
		// FILA vazia?
		if (vazia() == true)
		{
			// sim
			System.out.println("FILA vazia!");
		}
		else
		{
			// n�o, auxiliar-> 1� elemento da FILA
			Elemento auxiliar = FILA.prxElemento;

			System.out.print("FILA: ");
			// enquanto n�o chegar no �ltimo elemento inserido na FILA
			while(auxiliar.prxElemento != null)
			{
				// exibe o valor do elemento inserido nesse elemento
				System.out.print(auxiliar.dado + "  ");
				// auxiliar-> pr�ximo elemento da FILA
				auxiliar = auxiliar.prxElemento;
			}

			// exibe o valor do �ltimo elemento inserido na FILA
			System.out.println(auxiliar.dado);
		}
	}
}
