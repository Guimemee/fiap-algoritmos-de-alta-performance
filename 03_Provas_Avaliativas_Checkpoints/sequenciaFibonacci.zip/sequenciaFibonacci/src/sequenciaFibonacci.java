import java.util.Scanner;
import java.text.DecimalFormat;

public class sequenciaFibonacci
{
	public static void main(String[] args)
	{
		Scanner teclado = new Scanner(System.in);
		DecimalFormat classes = new DecimalFormat("###,###");
		int N;

		System.out.print("Qual elemento da Sequência de Fibonacci deseja obter (N)? ");
		N = teclado.nextInt();
		System.out.println("\nSequência de Fibonacci (iteração)");
		System.out.println("F(" + N + ")= " + classes.format(seqFibonacciIteracao(N)));
		System.out.println("\nSequência de Fibonacci (recursão)");
		System.out.println("F(" + N + ")= " + classes.format(seqFibonacciRecursao(N)));

		teclado.close();
	}

	public static long seqFibonacciIteracao(int n)
	{
		int i;
		long atual = 0, penultimo, ultimo;
	
		if (n == 0)
			return 0;
		else
			if (n == 1)
				return 1;
			else
			{
				penultimo = 0;
				ultimo = 1;
				for (i = 2; i <= n; i++)
				{
					atual = penultimo + ultimo;
					penultimo = ultimo;
					ultimo = atual;
				}
				return atual;
			}
	}

	public static long seqFibonacciRecursao(int n)
	{
		if (n == 0)
			return 0;
		else
			if (n == 1)
				return 1;
			else
				return (seqFibonacciRecursao(n-1) + seqFibonacciRecursao(n-2));
	}
}

/*
F(10) =                          55
F(20) =                       6.765
F(30) =                     832.040
F(40) =                 102.334.155
F(50) =              12.586.269.025
F(60) =           1.548.008.755.920
F(70) =         190.392.490.709.135
F(80) =      23.416.728.348.467.685
F(90) =   2.880.067.194.370.816.120
F(91) =   4.660.046.610.375.530.309
F(92) =   7.540.113.804.746.346.429
F(93) =  12.200.160.415.121.876.738
F(94) =  19.740.274.219.868.223.167
F(95) =	 31.940.434.634.990.099.905
F(96) =	 51.680.708.854.858.323.072
F(97) =	 83.621.143.489.848.422.977
F(98) = 135.301.852.344.706.746.049
F(99) = 218.922.995.834.555.169.026
F(100)= 354.224.848.179.261.915.075

Long.MAX_VALUE = 9.223.372.036.854.775.807
*/

